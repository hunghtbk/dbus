
Tooling
=======

Note that there has been a version update from CommonAPI 3.1.x to CommonAPI 3.2.x. The main reason for this update was the update of the FRANCA language itself from FRANCA 0.9.2 to FRANCA 0.13.x.

This means:

CommonAPI 3.1.x / yamaica 28.4 / FRANCA 0.9.2 

has been updated to:

CommonAPI 3.2.x / yamaica 29 or higher / FRANCA 0.13.x

The following description assumes that CommonAPI 3.2 shall be used. The provided FRANCA catalogue is already correct because the fdepl files import:

CommonAPI-4-SOMEIP_deployment_spec.fdepl

instead of CommonAPI-SOMEIP_deployment_spec.fdepl. Please make sure that you use the CommonAPI 3.2 code generators and link the CommonAPI 3.2 runtimes. 

Preparation
===========

- This description works in a Linux environment; for Windows the code generation works similar (use the Windows version of the code generators). For the runtime environment check the user guide.  
- It is assumed that the test folder has the path /home/mgu/work/local/test/. Please adapt the paths in the scripts according to your environment.
- The code generators are provided in test/cgen.
- The CommonAPI libraries are installed to /home/mgu/work/local/install/RELEASE32 (not provided). Set the path in compile.sh according to your environment.

Generate code and build shared library
======================================

- At the beginning src-gen and build should be empty. For your convenience the generated files and libraries are provided for comparison with your own results. 
- Start the code generaors with the script startcg.sh
- Call CMake as written in compile.sh
- Change to build and call make.
- The result should be the library mr.so which contains the generated code.  

 
