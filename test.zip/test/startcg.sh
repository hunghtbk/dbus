#!/bin/bash

PRJ_PATH=.

MY_GENERATOR_32_PATH=/home/mgu/work/local/test/cgen

CGEN_CORE=$MY_GENERATOR_32_PATH/commonapi_core_generator-3.2.4/commonapi-core-generator-linux-x86_64
CGEN_SOMEIP=$MY_GENERATOR_32_PATH/commonapi_someip_generator-3.2.4/commonapi-someip-generator-linux-x86_64

$CGEN_CORE -nv --skel $PRJ_PATH/FRANCA/*.fdepl
$CGEN_SOMEIP -nv $PRJ_PATH/FRANCA/*.fdepl

$CGEN_CORE -nv --skel $PRJ_PATH/FRANCA/MR/*.fdepl
$CGEN_SOMEIP -nv $PRJ_PATH/FRANCA/MR/*.fdepl

