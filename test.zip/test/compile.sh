#!/bin/bash

PRJ_PATH=.

INSTALL_PATH=/home/mgu/work/local/install/RELEASE32

cd $PRJ_PATH/build
cmake .. -DPRJ_GEN_PATH="/home/mgu/work/local/test/src-gen/" -DPRJ_INCLUDE_PATH="/home/mgu/work/local/test/src-gen" -DCMAKE_PREFIX_PATH=$INSTALL_PATH || exit 1
#make -j2 || exit 1

