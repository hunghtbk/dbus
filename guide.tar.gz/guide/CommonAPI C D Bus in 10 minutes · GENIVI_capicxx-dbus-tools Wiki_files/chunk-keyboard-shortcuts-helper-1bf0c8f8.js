System.register([],(function(e){"use strict";return{execute:function(){e("k",(()=>{const e=document.querySelector("meta[name=keyboard-shortcuts-preference]");return!e||"all"===e.content}))}}}));
//# sourceMappingURL=chunk-keyboard-shortcuts-helper-42aef116.js.map
